# Eventuales Monitor

Aplicación Android experimental que abre el sitio Eventuales en un WebView y muestra un indicador de estado.

## Corrección de compilación

Se agrega el plugin de Kotlin al proyecto. Sin `org.jetbrains.kotlin.android`, los archivos `.kt` no se compilan correctamente y la APK puede quedar sin las clases de la aplicación.

## Compilar desde GitHub Actions

1. Descomprimí este ZIP y subí **todo su contenido** a la raíz del repositorio. La carpeta `.github/workflows` debe quedar directamente en la raíz, junto a `app`, `build.gradle` y `settings.gradle` (no subas el ZIP como único archivo).
2. Abrí la pestaña **Actions**.
3. Ejecutá **Build Eventuales Monitor APK** con **Run workflow**, o hacé un commit a `main`/`master`.
4. Cuando termine, abrí la ejecución y descargá el artefacto `eventuales-monitor-debug-apk`.

La APK anterior no contenía el código compilado de la aplicación; este flujo comprueba que la nueva APK incluya `classes.dex` con tamaño razonable antes de publicarla. No pude ejecutar una compilación Android en este entorno, así que la validación final depende de que GitHub Actions termine correctamente. La aplicación es un prototipo y no realiza postulaciones automáticas.
