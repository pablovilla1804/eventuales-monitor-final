package com.eventuales.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class MonitorService : Service() {
    private var overlay: TextView? = null
    private var wm: WindowManager? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL_ID).setContentTitle("Eventuales Monitor activo").setContentText(currentStatus).setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).setOngoing(true).build()
        startForeground(7, n)
        showOverlay()
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "Eventuales Monitor", NotificationManager.IMPORTANCE_HIGH))
    }
    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return
        try {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val view = TextView(this).apply {
                text = "EVENTUALES\nINICIANDO…"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xE6123B67.toInt()); setPadding(18, 12, 18, 12)
                setOnClickListener {
                    val i = Intent(this@MonitorService, MainActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivity(i)
                }
            }
            val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.END; p.x = 18; p.y = 160
            wm?.addView(view, p); overlay = view
        } catch (_: Exception) {}
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { showOverlay(); return START_STICKY }
    override fun onDestroy() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
        overlay = null; instance = null; super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "eventuales_monitor"
        @Volatile private var currentStatus = "Preparando monitor"
        @Volatile private var lastAlertAt = 0L
        @Volatile private var instance: MonitorService? = null
        fun updateStatus(value: String) {
            currentStatus = value
            val s = instance ?: return
            Handler(Looper.getMainLooper()).post {
                s.overlay?.text = "EVENTUALES\n$value"
                val nm = s.getSystemService(NotificationManager::class.java)
                nm.notify(7, Notification.Builder(s, CHANNEL_ID).setContentTitle("Eventuales Monitor activo").setContentText(value).setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build())
            }
        }
        fun eventDetected(context: Context, value: String) {
            val now = System.currentTimeMillis()
            if (now - lastAlertAt < 10000) return
            lastAlertAt = now; updateStatus(value)
            try {
                val tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200)
                Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 1400)
            } catch (_: Exception) {}
            try {
                val v = context.getSystemService(Vibrator::class.java)
                if (Build.VERSION.SDK_INT >= 26) v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 150, 250, 150, 450), -1))
            } catch (_: Exception) {}
            val pi = PendingIntent.getActivity(context, 2, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.notify(8, Notification.Builder(context, CHANNEL_ID).setContentTitle("¡Reemplazo detectado!").setContentText("Tocá para abrir Eventuales Monitor").setSmallIcon(android.R.drawable.ic_dialog_alert).setContentIntent(pi).setAutoCancel(true).build())
        }
    }
}
