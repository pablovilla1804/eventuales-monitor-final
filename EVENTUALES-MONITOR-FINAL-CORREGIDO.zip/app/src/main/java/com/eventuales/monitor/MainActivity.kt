package com.eventuales.monitor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val targetUrl = "https://personal.seguridadciudad.gob.ar/Eventuales/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 59, 103)
        window.navigationBarColor = Color.rgb(18, 59, 103)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        status = TextView(this).apply {
            text = "EVENTUALES MONITOR · Abriendo página…"; textSize = 14f
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(18, 59, 103)); setPadding(16, 14, 16, 14)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(8, 4, 8, 4) }
        buttons.addView(Button(this).apply {
            text = "Activar monitor"
            setOnClickListener {
                askNotificationPermission()
                val si = Intent(this@MainActivity, MonitorService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(si) else startService(si)
                if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                status.text = "EVENTUALES MONITOR · Servicio solicitado"
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "Recargar página"; setOnClickListener { web.reload() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) { status.text = "EVENTUALES MONITOR · Página cargada"; injectMonitor() }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AndroidMonitor")
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        web.loadUrl(targetUrl)
    }

    private fun injectMonitor() {
        val js = """
            (function() {
              if (window.__eventualesMonitorInstalled) return;
              window.__eventualesMonitorInstalled = true;
              let previous = null;
              function scan() {
                try {
                  const grid = document.querySelector('#tablaEventosBody');
                  const buttons = Array.from(document.querySelectorAll('button.btnPostular'));
                  const signature = buttons.map(b => ((b.innerText || b.textContent || '').trim()) + '|' + (b.closest('tr')?.innerText || '')).join('||');
                  const pageText = document.body ? document.body.innerText : '';
                  const loading = /cargando|actualizando|loading/i.test(pageText);
                  let state = !grid ? 'ESPERANDO PÁGINA' : (loading ? 'ACTUALIZANDO' : (buttons.length ? 'EVENTOS DISPONIBLES' : 'SIN EVENTOS'));
                  if (previous !== null && signature !== previous && buttons.length > 0) {
                    state = '¡REEMPLAZO DETECTADO!';
                    try { AndroidMonitor.eventDetected(state); } catch(e) {}
                  }
                  previous = signature;
                  try { AndroidMonitor.status(state); } catch(e) {}
                } catch(e) { try { AndroidMonitor.status('ERROR DE LECTURA'); } catch(x) {} }
              }
              scan();
              setInterval(scan, 2500);
              new MutationObserver(scan).observe(document.documentElement, {childList:true, subtree:true, characterData:true});
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
    inner class Bridge {
        @JavascriptInterface fun status(value: String) {
            runOnUiThread { if (::status.isInitialized) status.text = "EVENTUALES MONITOR · $value" }
            MonitorService.updateStatus(value)
        }
        @JavascriptInterface fun eventDetected(value: String) { MonitorService.eventDetected(this@MainActivity, value) }
    }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
